package com.yourapp.desertcraftadmin.utils;

public class Val {
    public static final String BASE_URL = "http://192.168.0.104/desertcraft-portal/";
    public static final String IMG_URL = "http://192.168.0.104/desertcraft-portal/uploads/";

    public static final String status0 = "Pending Approval";
    public static final String status1 = "Order Accepted";
    public static final String status2 = "Need to Pay";
    public static final String status3 = "Preparing Order";
    public static final String status4 = "Ready to Pickup";
    public static final String status5 = "Completed";
    public static final String status6 = "Order Rejected";


    public static final int REWARD_POINT=50;
}

