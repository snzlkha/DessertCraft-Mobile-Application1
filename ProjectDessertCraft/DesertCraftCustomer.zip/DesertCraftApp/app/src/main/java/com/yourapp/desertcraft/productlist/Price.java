package com.yourapp.desertcraft.productlist;

public class Price {
    private String flavour;
    private String offerPrice;
    private String price;
    private String size;
    private String stock;
    private String weight;

    public String getFlavour() { return flavour; }
    public void setFlavour(String flavour) { this.flavour = flavour; }

    public String getOfferPrice() { return offerPrice; }
    public void setOfferPrice(String offerPrice) { this.offerPrice = offerPrice; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public String getStock() { return stock; }
    public void setStock(String stock) { this.stock = stock; }

    public String getWeight() { return weight; }
    public void setWeight(String weight) { this.weight = weight; }
}

