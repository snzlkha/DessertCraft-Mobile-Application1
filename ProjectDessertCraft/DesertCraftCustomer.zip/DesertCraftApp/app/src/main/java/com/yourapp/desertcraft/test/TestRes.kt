package com.yourapp.desertcraft.test

data class TestRes(
    val `data`: Data,
    val message: String,
    val success: Boolean
)