package com.yourapp.desertcraft.utils;

public class GradientUtils {
}
